# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: demo.spec.ts >> Demo 10 Tests Workflow >> Test 10 - should fail initially and pass when fixed
- Location: tests\demo.spec.ts:40:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Demo 10 Tests Workflow', () => {
  4  |   test('Test 1 - should always pass', async () => {
  5  |     expect(true).toBe(true);
  6  |   });
  7  | 
  8  |   test('Test 2 - should always pass', async () => {
  9  |     expect(true).toBe(true);
  10 |   });
  11 | 
  12 |   test('Test 3 - currently failing', async () => {
  13 |     expect(true).toBe(true);
  14 |   });
  15 | 
  16 |   test('Test 4 - currently failing', async () => {
  17 |     expect(true).toBe(true);
  18 |   });
  19 | 
  20 |   test('Test 5 - currently failing', async () => {
  21 |     expect(true).toBe(true);
  22 |   });
  23 | 
  24 |   test('Test 6 - should always pass', async () => {
  25 |     expect(true).toBe(true);
  26 |   });
  27 | 
  28 |   test('Test 7 - should always pass', async () => {
  29 |     expect(true).toBe(true);
  30 |   });
  31 | 
  32 |   test('Test 8 - should always pass', async () => {
  33 |     expect(true).toBe(true);
  34 |   });
  35 | 
  36 |   test('Test 9 - should always pass', async () => {
  37 |     expect(false).toBe(true);
  38 |   });
  39 | 
  40 |   test('Test 10 - should fail initially and pass when fixed', async () => {
  41 |     // FIX INSTRUCTION: Change `false` to `true` below to fix the test
> 42 |     expect(false).toBe(true);
     |                   ^ Error: expect(received).toBe(expected) // Object.is equality
  43 |   });
  44 | });
  45 | 
```